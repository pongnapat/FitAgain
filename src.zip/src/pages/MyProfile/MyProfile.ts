import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

import { Friend } from '../Friend/Friend';
import { Meal } from '../Meal/Meal';
import { Goal } from '../Goal/Goal';

@Component({
  selector: 'MyProfile',
  templateUrl: 'MyProfile.html'
})
export class MyProfile {
  pages: Array<{title: string, component: any}>;
  constructor(public navCtrl: NavController) {
    this.pages = [
      { title: 'Friend', component: Friend },
      { title: 'Meal', component: Meal },
      { title: 'Goal', component: Goal }
    ];
  }
  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.navCtrl.setRoot(page.component);
  }
}

/*
userlist
|-ID(bra bra bra)
  |-username: temy
  |-meal
    |-meal1: aaa

*/