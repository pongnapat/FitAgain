import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';

import {FormGroup,FormControl} from '@angular/forms';

import { FillInfo } from '../FillInfo/FillInfo';
import { MyProfile } from '../MyProfile/MyProfile';

@Component({
  selector: 'Goal',
  templateUrl: 'Goal.html'
})
export class Goal {

  pageback: Array<{title: string, component: any}>;
  pageforward: Array<{title: string, component: any}>;
  constructor(public navCtrl: NavController) {
    this.pageforward = [
      { title: 'MyProfile', component: MyProfile },
    ];
    this.pageback = [
      { title: 'FillInfo', component: FillInfo },
    ];
  }
  openPage(page) {
    this.navCtrl.setRoot(page.component);  
  }


}
