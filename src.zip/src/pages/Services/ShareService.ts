import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';

export class ShareService {  
  
    mealName: string;
    mealDescription: string;
    mealKcal: number;
 
    constructor() {
        this.mealName = 'Blank';
        this.mealDescription = 'Name';
        this.mealKcal = 0;
    }
  
    setMeal(Name, Description, Kcal) {
        this.mealName = Name;
        this.mealDescription = Description;       
        this.mealKcal = Kcal;    
    }
  
}