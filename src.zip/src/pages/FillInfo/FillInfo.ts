import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';

import {FormGroup,FormControl} from '@angular/forms';

import { Goal } from '../Goal/Goal';
import { Activity } from '../Activity/Activity';

@Component({
  selector: 'FillInfo',
  templateUrl: 'FillInfo.html'
})
export class FillInfo {

  pageback: Array<{title: string, component: any}>;
  pageforward: Array<{title: string, component: any}>;
  constructor(public navCtrl: NavController) {
    this.pageforward = [
      { title: 'Goal', component: Goal },
    ];
    this.pageback = [
      { title: 'Activity', component: Activity },
    ];
  }
  openPage(page) {
    this.navCtrl.setRoot(page.component);  
  }


}
