import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';

import { AddMeal } from '../AddMeal/AddMeal';
import { EditMeal } from '../EditMeal/EditMeal';
import { ShareService } from "../Services/ShareService";

@Component({
  selector: 'Meal',
  templateUrl: 'Meal.html'
})
export class Meal {

  selectedItem: any;
  icons: string[];
  items: Array<{title: string, note: string, icon: string}>;


  Name: string;
  Description: string;
  Kcal: number;

  constructor(private navCtrl: NavController, public navParams: NavParams, private shareService: ShareService) {
    // If we navigated to this page, we will have an item available as a nav param
    this.selectedItem = navParams.get('item');

    // Let's populate this page with some filler content for funzies
    this.icons = ['egg', 'water'];

    this.items = [];
    for (let i = 1; i < 11; i++) {
      this.items.push({
        title: 'Food ' + i,
        note: 'Kcal ' + i,
        icon: this.icons[Math.floor(Math.random() * this.icons.length)]
      });
    }

    this.Name = navParams.get('InputName');
    this.Description = navParams.get('InputDescription');
    this.Kcal = navParams.get('InputKcal');
  }

  openPage() {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.navCtrl.setRoot(AddMeal);
  }

  openEditPageWithData() {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.navCtrl.push(EditMeal, {
        name: this.Name, description: this.Description, kcal: this.Kcal
    });
  }
}
