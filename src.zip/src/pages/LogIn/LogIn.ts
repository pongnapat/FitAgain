import { Component } from '@angular/core';
import { AuthProviders, AuthMethods, AngularFire } from 'angularfire2'
import { NavController } from 'ionic-angular';

import { MyProfile } from '../MyProfile/MyProfile';

@Component({
  selector: 'LogIn',
  templateUrl: 'LogIn.html'
})

export class LogIn {
  email: any;
  password: any;
  constructor(public navCtrl: NavController, public angfire:AngularFire) { }
  login(){
    this.angfire.auth.login({
      email: this.email,
      password: this.password
    },{
      provider: AuthProviders.Password,
      method: AuthMethods.Password
    }).then((response) => {
      let currentuser = {
        email: response.auth.email,
      };
      window.localStorage.setItem('currentuser',JSON.stringify(currentuser));
      this.navCtrl.setRoot(MyProfile);
    }).catch((error) =>{
      console.log(error);
    });
  }
}
