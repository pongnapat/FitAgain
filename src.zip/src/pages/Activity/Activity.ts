import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';

import {FormGroup,FormControl} from '@angular/forms';

import { FillInfo } from '../FillInfo/FillInfo';
import { First } from '../First/First';

@Component({
  selector: 'Activity',
  templateUrl: 'Activity.html'
})
export class Activity {
  pageback: Array<{title: string, component: any}>;
  pageforward: Array<{title: string, component: any}>;
  constructor(public navCtrl: NavController) {
    this.pageforward = [
      { title: 'FillInfo', component: FillInfo },
    ];
    this.pageback = [
      { title: 'First', component: First },
    ];
  }
  openPage(page) {
    this.navCtrl.setRoot(page.component);  
  }

}


