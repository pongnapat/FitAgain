import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'AddMeal',
  templateUrl: 'AddMeal.html'
})
export class AddMeal {
  searchQuery: string = '';
  items:any;
  constructor(public navCtrl: NavController) {
    this.initializeItems();
  }

  initializeItems() {
    this.items = [
      {name:'Fried Rice', detail:'A rice fried with anything', kcal: 300},
      {name:'Pizza', detail:'A popular italian food', kcal: 500},
    ];
    
  }

  getItems(ev: any) {
    // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    let val = ev.target.value;

    // if the value is an empty string don't filter the items
    if (val && val.trim() != '') {
      this.items = this.items.filter((item) => {
        return (item.name.toLowerCase().indexOf(val.toLowerCase()) > -1);
      })
    }
  }

}
