import { Component } from '@angular/core';

import { NavController, NavParams, AlertController } from 'ionic-angular';
import { AuthProviders, AuthMethods, AngularFire } from 'angularfire2' //,FirebaseListObservable////////////////////////////////////////////////////////////////////////////
import { FormGroup,FormControl} from '@angular/forms';

import { Activity } from '../Activity/Activity';
//https://www.youtube.com/watch?v=O_jxEC0hWcA
@Component({
  selector: 'Register',
  templateUrl: 'Register.html'
})
export class Register {
  email: any;
  password: any;
  conpassword: any;
  error: any;
  //userlist: FirebaseListObservable<any>;////////////////////////////////////////////////////////////////////////////
  constructor(public navCtrl: NavController,public angfire:AngularFire) {
     //this.userlist = angfire.database.list('/userlist');////////////////////////////////////////////////////////////////////////////
     //build an empty leave and push reminder, meal and more about list by using angfire.database.list('/userlist/.../...');
  }
  register(){
    if(this.conpassword == this.password){
     this.angfire.auth.createUser({
       email: this.email,
       password: this.password
     }).then(
       (success) => {
        this.angfire.auth.login({
          email: this.email,
          password: this.password
        },{
          provider: AuthProviders.Password,
          method: AuthMethods.Password
        }).then((response) => {
          let currentuser = {
            email: response.auth.email,
          };
          window.localStorage.setItem('currentuser',JSON.stringify(currentuser));
          //this.userlist.push({username: this.email, password: this.password})////////////////////////////////////////////////////////////////////////////
          this.navCtrl.setRoot(Activity);
        }).catch((err) =>{
          console.log(err);
          this.error = err;
        });
       }).catch(
         (err) => {
           console.log(err);
           this.error = err;
         }
       )
    }
    else this.error = "password is not match!"
  }
}
