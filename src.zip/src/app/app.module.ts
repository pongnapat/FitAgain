import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler, NavController } from 'ionic-angular';
import { MyApp } from './app.component';
import { First } from '../pages/First/First';
//import { Home } from '../pages/Home/Home';
import { LogIn } from '../pages/LogIn/LogIn';
import { Activity } from '../pages/Activity/Activity';
import { FillInfo } from '../pages/FillInfo/FillInfo';
import { Goal } from '../pages/Goal/Goal';
import { Register } from '../pages/Register/Register';
import { MyProfile } from '../pages/MyProfile/MyProfile';
import { Meal } from '../pages/Meal/Meal';
import { EditMeal } from '../pages/EditMeal/EditMeal';
import { AddMeal } from '../pages/AddMeal/AddMeal';
import { Nutrition } from '../pages/Nutrition/Nutrition';
import { Reminder } from '../pages/Reminder/Reminder';
import { AddReminder } from '../pages/AddReminder/AddReminder';
import { AngularFireModule } from 'angularfire2'
const config = {
    apiKey: "AIzaSyBatM2imKBiuePC8OzJZCP3vnDaNN0eO8M",
    authDomain: "fitagain-d76c7.firebaseapp.com",
    databaseURL: "https://fitagain-d76c7.firebaseio.com",
    projectId: "fitagain-d76c7",
    storageBucket: "fitagain-d76c7.appspot.com",
    messagingSenderId: "983097697461"
  };
@NgModule({
  declarations: [
    MyApp,
    First,
    //Home,
    LogIn,
    Activity,
    FillInfo,
    Goal,
    Register,
    Reminder,
    AddReminder,
    MyProfile,
    Meal,
    EditMeal,
    AddMeal,
    Nutrition
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    AngularFireModule.initializeApp(config)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    First,
    //Home,
    LogIn,
    Activity,
    FillInfo,
    Goal,
    Register,
    Reminder,
    AddReminder,
    MyProfile,
    Meal,
    EditMeal,
    AddMeal,
    Nutrition
  ],
  providers: [{provide: ErrorHandler, useClass: IonicErrorHandler}]
})
export class AppModule {}
