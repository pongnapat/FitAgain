import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, NavController } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';

import { First } from '../pages/First/First';
//import { Home } from '../pages/Home/Home';
import { LogIn } from '../pages/LogIn/LogIn';
import { Activity } from '../pages/Activity/Activity';
import { FillInfo } from '../pages/FillInfo/FillInfo';
import { Goal } from '../pages/Goal/Goal';
import { Register } from '../pages/Register/Register';
import { MyProfile } from '../pages/MyProfile/MyProfile';
import { Meal } from '../pages/Meal/Meal';
import { EditMeal } from '../pages/EditMeal/EditMeal';
import { AddMeal } from '../pages/AddMeal/AddMeal';
import { Nutrition } from '../pages/Nutrition/Nutrition';
import { Reminder } from '../pages/Reminder/Reminder';
import { AddReminder } from '../pages/AddReminder/AddReminder';
import { ShareService } from '../pages/Services/ShareService'
//https://www.youtube.com/channel/UCEBB26M5pGEMvxsn_ZuAfUg
@Component({
  templateUrl: 'app.html',
  providers: [ShareService]
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = First;

  pages: Array<{title: string, component: any}>;

  constructor(public platform: Platform) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'First', component: First },
    //  { title: 'Home', component: Home },
      { title: 'LogIn', component: LogIn },
      { title: 'Activity', component: Activity },
      { title: 'FillInfo', component: FillInfo },
      { title: 'Goal', component: Goal },
      { title: 'Register', component: Register },
      { title: 'Reminder', component: Reminder },
      { title: 'AddReminder', component: AddReminder },
      { title: 'MyProfile', component: MyProfile },
      { title: 'Meal', component: Meal },
      { title: 'EditMeal', component: EditMeal },
      { title: 'AddMeal', component: AddMeal },
      { title: 'Nutrition', component: Nutrition }
    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      StatusBar.styleDefault();
      Splashscreen.hide();
    });
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
}
