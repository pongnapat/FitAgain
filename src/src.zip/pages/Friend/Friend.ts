import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

@Component({
  selector: 'Friend',
  templateUrl: 'Friend.html'
})
export class Friend {

  constructor(public navCtrl: NavController) {
    
  }

}
