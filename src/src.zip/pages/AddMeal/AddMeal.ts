import { Component } from '@angular/core';

import { NavController, AlertController } from 'ionic-angular';
import { AngularFire, FirebaseListObservable } from 'angularfire2'

import { ShareService } from "../Services/ShareService";
import { Meal } from "../Meal/Meal";

@Component({
  selector: 'addMeal',
  templateUrl: 'addMeal.html'
})
export class addMeal {
  selected: string;
  amount: number;
  MealList: FirebaseListObservable<any>;
  Mealuser: FirebaseListObservable<any>;
  cals: any;
  constructor(private navCtrl: NavController, private shareService: ShareService, public alertctrl: AlertController, public angfire: AngularFire) {
    this.MealList = angfire.database.list('/meal');
    this.Mealuser = angfire.database.list('/user/'+shareService.getCurrentUser());
  }
  cancel(){
     this.navCtrl.setRoot(Meal);
  }
  addMeal(name,calories){
    console.log("Name : "+name+" Cal : "+calories);

    this.Mealuser.push({
          name: name,
          cal: calories
    });
    
    this.navCtrl.setRoot(Meal);
  }
}
