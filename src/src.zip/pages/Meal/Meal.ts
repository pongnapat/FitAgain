import { Component } from '@angular/core';

import { NavController, AlertController } from 'ionic-angular';
import {AngularFire, FirebaseListObservable } from 'angularfire2'

import { ShareService } from "../Services/ShareService";
import { addMeal } from "../addMeal/addMeal";

@Component({
  selector: 'Meal',
  templateUrl: 'Meal.html'
})
export class Meal {
  Mealuser: FirebaseListObservable<any>;
  constructor(private navCtrl: NavController, private shareService: ShareService, public alertctrl: AlertController, public angfire: AngularFire) {
    this.Mealuser = angfire.database.list('/user/'+shareService.getCurrentUser()+"/meal");
  }
  addMeal(){
    this.navCtrl.setRoot(addMeal);
  }
}
