import { Component } from '@angular/core';
import { AuthProviders, AuthMethods, AngularFire } from 'angularfire2'
import { NavController } from 'ionic-angular';

import { MyProfile } from '../MyProfile/MyProfile';
import { ShareService } from '../Services/ShareService';

@Component({
  selector: 'LogIn',
  templateUrl: 'LogIn.html'
})
//https://github.com/angular/angularfire2/blob/master/docs/4-querying-lists.md
export class LogIn {
  email: any;
  password: any;
  constructor(public navCtrl: NavController, public angfire:AngularFire,public shareService: ShareService) {
  }
  login(){
    this.angfire.auth.login({
      email: this.email,
      password: this.password
    },{
      provider: AuthProviders.Password,
      method: AuthMethods.Password
    }).then((response) => {
      this.shareService.setCurrentUser(this.email);
      this.navCtrl.setRoot(MyProfile);
    }).catch((error) =>{
      console.log(error);
    });
  }
}
