import { Component } from '@angular/core';

import { NavController, AlertController } from 'ionic-angular';
import {  FirebaseListObservable } from 'angularfire2/database';
import { AngularFire } from 'angularfire2'
import { Meal } from '../Meal/Meal';
import { Goal } from '../Goal/Goal';
import {ShareService} from '../Services/ShareService';


@Component({
  selector: 'MyProfile',
  templateUrl: 'MyProfile.html'
})
export class MyProfile {
  items: FirebaseListObservable<any>;
  user: FirebaseListObservable<any>;
  itemss: FirebaseListObservable<any>;
  activitytype: string;
  KcalActivity: number;
  hour: number;
  NowcurrentKcal: number;
  newCal: number;
  constructor(public navCtrl: NavController, public shareService: ShareService,public angfire:AngularFire, public alertcon :AlertController) {
    this.user = angfire.database.list('/user',{preserveSnapshot:true});
    this.items = this.angfire.database.list('/user',{
        query:{
          orderByKey: true,
          equalTo: this.shareService.getCurrentUser()
        }
    });


    this.itemss = this.angfire.database.list('/user',{
      query: {
          orderByKey: true,
          equalTo: shareService.getCurrentUser()
      },preserveSnapshot:true
    });
    this.itemss.subscribe(snapshots => {
      snapshots.forEach(snapshot => {
        this.activitytype = snapshot.val().activity;
        this.NowcurrentKcal = snapshot.val().currentKcal;
        this.KcalActivity = snapshot.val().KcalActivity;
      });
    });

  }
  activity() {
    this.user.update(this.shareService.getCurrentUser(),{
      currentKcal: this.NowcurrentKcal-this.hour*this.KcalActivity
    })
  }
  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.navCtrl.setRoot(page.component);
  }
}
