import { Component } from '@angular/core';

import { NavController, NavParams } from 'ionic-angular';

import { AddReminder } from '../AddReminder/AddReminder';

@Component({
  selector: 'Reminder',
  templateUrl: 'Reminder.html'
})
export class Reminder {
  selectedItem: any;
  icons: string[];
  items: Array<{title: string, note: string, icon: string}>;
  noti : any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.noti = this.navParams.get('notification');
    console.log(this.noti);
  } 

  

    openPage() {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.navCtrl.setRoot(AddReminder);
    }
}
